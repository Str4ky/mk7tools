# SARC Tool v0.5
A tool for extracting and packing SARC/SZS files.  
Makes use of SarcLib and libyaz0.  

## Usage:
 * `sarc_tool [Option...] file/folder`  
All the options are optional.
 
## Options:
Please run `sarc_tool` to see the list of options.
